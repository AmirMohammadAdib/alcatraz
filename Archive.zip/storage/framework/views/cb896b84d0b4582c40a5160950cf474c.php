<title>پنل مدیریت آلکاتراز</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="قالب مدیریت ایرانی مدیران ">
        <meta name="keywords" content="قالب مدیریت, قالب داشبورد, قالب ادمین, قالب مدیران, قالب مدیریت راستچین , قالب ایرانی مدیریت, پوسته مدیریت, قالب ادمین داشبورد سایت, قالب مدیریتی, مدیران, قالب مدیریت مدیران, پنل مدیریت, پنل مدیریت مدرن, قالب ادمین متریال, قالب مدیریت بوت استرپ, قالب ادمین بوتسترپ, قالب ادمین سایت, پوسته مدیریتی ایرانی, قالب مدیرتی مدیران ایرانی, بهترین قالب مدیریت, قالب مدیریت ریسپانسیو, قالب مدیریت ارزان, قالب admin">
        <meta name="fontiran.com:license" content="NE29X">
        <link rel="shortcut icon" href="<?php echo e(asset('admin-assets/images/favicon.png')); ?>">

        <!-- BEGIN CSS -->
        <link href="<?php echo e(asset('admin-assets/plugins/bootstrap/bootstrap5/css/bootstrap.rtl.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/metisMenu/dist/metisMenu.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/simple-line-icons/css/simple-line-icons.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/font-awesome/css/all.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/switchery/dist/switchery.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/sweetalert2/dist/sweetalert2.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/paper-ripple/dist/paper-ripple.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/iCheck/skins/square/_all.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/css/style.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/css/colors.css')); ?>" rel="stylesheet">
        <!-- END CSS -->
        <!-- BEGIN PAGE CSS -->
        <link href="<?php echo e(asset('admin-assets/plugins/morris.js/morris.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/plugins/kamadatepicker/kamadatepicker.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('admin-assets/css/effects.css')); ?>" rel="stylesheet">
        <!-- END PAGE CSS --><?php /**PATH /Users/amir/Desktop/gaming/resources/views/admin/layouts/head-tag.blade.php ENDPATH**/ ?>