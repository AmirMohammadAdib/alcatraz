<!DOCTYPE html>
<html lang="fa" dir="rtl" class="rtl">
    <head>
        <?php echo $__env->make('admin.layouts.head-tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('head-tag'); ?>
    </head>
    <body class="active-ripple theme-darkpurple fix-header sidebar-extra bg-1 dark">
        <!-- BEGIN LOEADING -->
        <div id="loader">
            <div class="spinner"></div>
        </div><!-- /loader -->
        <!-- END LOEADING -->
        
        <!-- BEGIN HEADER -->
            <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
        <!-- END HEADER -->
              
        <!-- BEGIN WRAPPER -->
        <div id="wrapper">

            <!-- BEGIN SIDEBAR -->
                <?php echo $__env->make('admin.layouts.nav-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- END SIDEBAR -->     

            <!-- BEGIN PAGE CONTENT -->

            <div id="page-content">
                <div id="inner-content">
                    <div class="row">    
                        <div class="col-md-12">
                            <div class="breadcrumb-box shadow"> 
                                <ul class="breadcrumb">
                                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                                </ul>
                                <div class="breadcrumb-left">
                                    <?php echo e(verta()->formatWord('l dS F')); ?>

                                    <i class="icon-calendar"></i>
                                </div><!-- /.breadcrumb-left -->
                            </div><!-- /.breadcrumb-box -->


                            <?php echo $__env->yieldContent('content'); ?>
                        </div><!-- /.col-md-12 -->
                    </div>
                </div>
            </div>
        </div><!-- /#wrapper -->
        <!-- END WRAPPER -->


        
        <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('admin.layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html><?php /**PATH /Users/amir/Desktop/gaming/resources/views/admin/layouts/master.blade.php ENDPATH**/ ?>