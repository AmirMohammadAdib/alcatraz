<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- استایل منو فوتر و صفحات بیس مثل هوم درباره ما تماس با ما بلاگ و سینگل بلاگ -->
<link rel="stylesheet" href="<?php echo e(asset('asset/stylesheets/basic.css')); ?>" />
<!-- فایل های کمکی و مینی کتابخونه من -->
<link rel="stylesheet" href="<?php echo e(asset('asset/stylesheets/helper.css')); ?>" />
<!-- کامپوننت ها در صورت وجود -->
<link rel="stylesheet" href="<?php echo e(asset('asset/stylesheets/components.css')); ?>" />
<?php /**PATH /Users/amir/Desktop/gaming/resources/views/app/layouts/head-tag.blade.php ENDPATH**/ ?>