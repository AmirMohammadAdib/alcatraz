<?php $__env->startSection('head-tag'); ?>
    <title>آلکاتراز</title>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="team row justify-content-center mt-20">
      <div team-id="bg_1" class="team-item col-12 col-md-6">
        <div class="item-head">
          <h3>تیم اول</h3>
        </div>
        <div class="item-users d-flex">
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
        </div>
      </div>
      <div team-id="bg_2" class="team-item col-12 col-md-6">
        <div class="item-head">
          <h3>تیم اول</h3>
        </div>
        <div class="item-users d-flex">
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
        </div>
      </div>
      <div team-id="bg_3" class="team-item col-12 col-md-6">
        <div class="item-head">
          <h3>تیم اول</h3>
        </div>
        <div class="item-users d-flex">
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
        </div>
      </div>
      <div team-id="bg_4" class="team-item col-12 col-md-6">
        <div class="item-head">
          <h3>تیم اول</h3>
        </div>
        <div class="item-users d-flex">
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
        </div>
      </div>
      <div team-id="bg_5" class="team-item col-12 col-md-6">
        <div class="item-head">
          <h3>تیم اول</h3>
        </div>
        <div class="item-users d-flex">
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
        </div>
      </div>
      <div team-id="bg_6" class="team-item col-12 col-md-6">
        <div class="item-head">
          <h3>تیم اول</h3>
        </div>
        <div class="item-users d-flex">
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
          <div class="user">
            <img
              src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
              alt=""
            />
            <span>AmirAdib</span>
          </div>
        </div>
      </div>
      <div team-id="bg_7" class="team-item col-12 col-md-6">
          <div class="item-head">
            <h3>تیم اول</h3>
          </div>
          <div class="item-users d-flex">
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
          </div>
      </div>
      <div team-id="bg_3" class="team-item col-12 col-md-6">
          <div class="item-head">
            <h3>تیم اول</h3>
          </div>
          <div class="item-users d-flex">
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
            <div class="user">
              <img
                src="<?php echo e(asset('asset/src/test/آفر-دوبل-سی-پی-mobile.jpg 1.png')); ?>"
                alt=""
              />
              <span>AmirAdib</span>
            </div>
          </div>
        </div>


    </div>
  </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/amir/Desktop/gaming/resources/views/app/room.blade.php ENDPATH**/ ?>