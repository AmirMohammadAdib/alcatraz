<script>
    let progress_box = document.querySelector(".progress-box .box")
    let progress_width = progress_box.getAttribute("data-width")
    progress_box.style.width=progress_width + "%"
</script><?php /**PATH /Users/amir/Desktop/gaming/resources/views/app/layouts/scripts.blade.php ENDPATH**/ ?>