<?php $__env->startSection('head-tag'); ?>
    <title>فهرست تیکت ها سایت - آلکاتراز</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li><a href="<?php echo e(route('dashboard')); ?>">پیشخوان</a></li>
    <li><a href="">تیکت</a></li>
    <li><a href="">تیکت ها</a></li>
    <li><a href="">مشاهده تیکت تست</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="portlet box shadow">
        <div class="portlet-heading">
            <div class="portlet-title">
                <h3 class="title">                                        
                    <i class="icon-frane"></i>
                    لیست تیکت ها
                </h3>
            </div><!-- /.portlet-title -->
            <div class="buttons-box">
                <a class="btn btn-sm btn-default btn-round btn-fullscreen" rel="tooltip" title="تمام صفحه" href="#">
                    <i class="icon-size-fullscreen"></i>
                </a>
                <a class="btn btn-sm btn-default btn-round btn-collapse" rel="tooltip" title="کوچک کردن" href="#">
                    <i class="icon-arrow-up"></i>
                </a>
            </div><!-- /.buttons-box -->
        </div><!-- /.portlet-heading -->
        <div class="portlet-body">

            


  <section class="row">
    <section class="col-12">
        <section class="main-body-container">
            <section class="main-body-container-header">
                <h5>
                نمایش تیکت ها
                </h5>
            </section>

            <section class="d-flex justify-content-between align-items-center mt-4 mb-3 border-bottom pb-2">
                <a href="<?php echo e(route('admin.ticket.index')); ?>" class="btn btn-info btn-sm">بازگشت</a>
            </section>

            <section class="card mb-3">
                <section class="card-header bg-custom-pink">amiradib - 3</section>
                <section class="card-header bg-custom-pink">
                    <h5>موضوع : تست</h5>
                    <p>تست</p>
                </section>
            </section>

            <div class="border my-2">
                <section class="card m-4">
                    <section class="card-header d-flex justify-content-between">
                        <div> adib - پاسخ دهنده :
                            amir adib</div>
                        <small>۱۱۱۱/۱۱/۱۱</small>
                    </section>
                    <section class="card-header bg-custom-pink">
                        <p>تست</p>
                    </section>

                </section>
                        </div>

            <section>
                <form action="<?php echo e(route('admin.ticket.answer', 1)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <section class="row">
                        <section class="col-12">
                            <div class="form-group">
                                <label for="">پاسخ تیکت </label>
                               ‍<textarea class="form-control form-control-sm" rows="4" name="description"><?php echo e(old('description')); ?></textarea>
                            </div>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="alert_required bg-danger text-white p-1 rounded" role="alert">
                                <strong>
                                    <?php echo e($message); ?>

                                </strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </section>
                        <section class="col-12">
                            <button class="btn btn-primary btn-sm">ثبت</button>
                        </section>
                    </section>
                </form>
            </section>

        </section>
    </section>
</section>


        </div><!-- /.portlet-body -->
    </div><!-- /.portlet -->
</div><!-- /.col-lg-12 -->                  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/amir/Desktop/gaming/resources/views/admin/ticket/show.blade.php ENDPATH**/ ?>