Ladda.bind('.ladda-button', {timeout: 2000});
