<?php

namespace App\Http\Controllers;

use App\Models\Ticket;
use GuzzleHttp\Psr7\Request;

abstract class Controller
{

}
